from ariblib import command

if __name__ == '__main__':
    command.main()
